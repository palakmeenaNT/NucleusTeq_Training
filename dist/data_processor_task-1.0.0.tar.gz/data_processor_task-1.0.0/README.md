# Member Data Management System

## Description
This project is a Python-based Member Data Management System developed as part of the Core Python Concepts Assignment.

## Features
- Stores member data using lists and dictionaries.
- Validates email addresses and phone numbers using Regular Expressions.
- Uses Object-Oriented Programming with a Member class.
- Handles invalid data using a custom exception.
- Demonstrates Functional Programming using lambda and filter().
- Packaged as a Python Wheel (.whl).

## Technologies Used
- Python 3
- Regular Expressions (re)
- Object-Oriented Programming
- Python Packaging (setuptools)

## Author
Palak Meena