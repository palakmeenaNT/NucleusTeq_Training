import re



def clean_text(text):
    """Remove extra spaces and return cleaned text."""
    text = text.strip()
    return text[:]



def validate_email(email):
    """Validate email using regular expression."""
    pattern = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$"
    return bool(re.fullmatch(pattern, email))



def validate_phone(phone):
    """Validate phone number in the format 555-0101."""
    pattern = r"^\d{3}-\d{4}$"
    return bool(re.match(pattern, phone))