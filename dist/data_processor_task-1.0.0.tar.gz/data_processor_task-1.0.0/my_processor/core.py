class InvalidMemberDataError(Exception):
    """Custom exception for invalid member data."""
    pass



class Member:
    def __init__(self, name, email, phone):
        if not name:
            raise InvalidMemberDataError("Member name cannot be empty.")

        self.name = name.strip()
        self.email = email.strip()
        self.phone = phone.strip()

    def __str__(self):
        return (
            f"Name: {self.name}, "
            f"Email: {self.email}, "
            f"Phone: {self.phone}"
        )