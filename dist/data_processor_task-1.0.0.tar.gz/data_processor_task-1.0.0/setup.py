from setuptools import setup, find_packages
setup(
    name="data_processor_task",
    version="1.0.0",
    description="A core Python training assignment project",
    author="Palak Meena",
    packages=find_packages(),
    include_package_data=True,
)
